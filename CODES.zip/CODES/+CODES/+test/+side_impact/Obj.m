function Y=Obj(U)
    % Weight
    Y=1.98+U*[4.9 6.67 6.98 4.01 1.78 0 2.73]';
end